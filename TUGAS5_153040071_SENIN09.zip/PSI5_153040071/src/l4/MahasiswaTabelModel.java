/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l4;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author noviyapar
 */

public class MahasiswaTabelModel extends AbstractTableModel {

    private List<Mahasiswa> mhList;
    private String[] header = {"NRP", "Nama","IPK"};

    public MahasiswaTabelModel(List<Mahasiswa> mhList) {
        this.mhList = mhList;
    }

    public List<Mahasiswa> getMhList() {
        return mhList;
    }

    public void setMhList(List<Mahasiswa> mhList) {
        this.mhList = mhList;
    }

    public String[] getHeader() {
        return header;
    }

    public void setHeader(String[] header) {
        this.header = header;
    }

    @Override
    public int getRowCount() {
        return mhList.size();
    }

    @Override
    public int getColumnCount() {
        return header.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            return mhList.get(rowIndex).getNrp();
        } else if (columnIndex == 1) {
            return mhList.get(rowIndex).getNama();
        } else if (columnIndex == 2) {
            return mhList.get(rowIndex).getIpk();
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        return header[column];
    }

}