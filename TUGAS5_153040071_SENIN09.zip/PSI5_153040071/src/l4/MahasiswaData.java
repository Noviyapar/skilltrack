/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package l4;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author noviyapar
 * 
 */

public class MahasiswaData {
    public static List<Mahasiswa> getMahasiswa() {
        List<Mahasiswa> mhList = new ArrayList<Mahasiswa>();
        return mhList;
    }  
}
