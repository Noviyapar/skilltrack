/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author SB60-35
 */
public class MahasiswaDBTest {
    
    public static void main(String[] args) {
        MahasiswaDB db = new MahasiswaDB();
        StringBuilder sb = new StringBuilder();
        sb.append("Daftar Mahasiswa : \n");
        
        try {
            List<Mahasiswa> mhsList = db.findAll();
            for (Mahasiswa mhs : mhsList){
                sb.append(mhs.getNrp());
                sb.append("-");
                sb.append(mhs.getNama());
                sb.append("-");
                sb.append(mhs.getIpk());
                sb.append("-");
            }
            
            JOptionPane.showMessageDialog(null, sb.toString());
        } catch(SQLException ex){
            JOptionPane.showConfirmDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
